﻿using Financeiro.Model;
using Financeiro.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Financeiro.Controller
{
    public class LancamentoController
    {
        public List<LancamentoViewModel> Obter(int contaId)
        {
            List<Lancamento> lancamentos = new Lancamento().Obter(contaId);
            if (lancamentos != null)
            {
                return (from Lancamento l in lancamentos
                        select new LancamentoViewModel()
                        {
                            Id = l.Id,
                            Conta = null,
                            ContaId = l.ContaId,
                            ContaNumero = l.Conta.Agencia + "/" + l.Conta.Numero,
                            Data = l.Data,
                            Descricao = l.Descricao,
                            Documentos = null,
                            Tipo = l.Tipo,
                            Valor = l.Valor
                        }).ToList();
            }
            else
                return null;
        }

        public LancamentoViewModel ObterLancamento(int id)
        {
            Lancamento l = new Lancamento().ObterLancamento(id);
            if (l != null)
                return new LancamentoViewModel()
                {
                    Id = l.Id,
                    Conta = null,
                    ContaId = l.ContaId,
                    ContaNumero = l.Conta.Agencia + "/" + l.Conta.Numero,
                    Data = l.Data,
                    Descricao = l.Descricao,
                    Documentos = null,
                    Tipo = l.Tipo,
                    Valor = l.Valor
                };
            else
                return null;    
        }

        public List<LancamentoViewModel> ObterPeriodo(DateTime dataInicial, DateTime dataFinal, int contaId)
        {
            List<Lancamento> lancamentos = new Lancamento().ObterPeriodo(dataInicial, dataFinal, contaId);
            if (lancamentos != null)
            {
                return (from Lancamento l in lancamentos
                        select new LancamentoViewModel()
                        {
                            Id = l.Id,
                            Conta = null,
                            ContaId = l.ContaId,
                            ContaNumero = l.Conta.Agencia + "/" + l.Conta.Numero,
                            Data = l.Data,
                            Descricao = l.Descricao,
                            Documentos = null,
                            Tipo = l.Tipo,
                            Valor = l.Valor
                        }).ToList();
            }
            else
                return null;
        }

        public decimal Saldo(DateTime dataInicial, DateTime dataFinal, int contaId)
        {
            Lancamento l = new Lancamento();
            return l.Saldo(dataInicial, dataFinal, contaId);
        }

        public int Gravar(LancamentoViewModel lancamento)
        {
            if (lancamento != null)
            {
                Lancamento l = new Lancamento();
                l.Id = lancamento.Id;
                l.Tipo = lancamento.Tipo;
                l.Data = lancamento.Data;
                l.Descricao = lancamento.Descricao;
                l.Valor = lancamento.Valor;
                l.ContaId = lancamento.ContaId;
                l.Conta = null;
                l.Documentos = null;

                return l.Gravar();
            }
            else
                return -10;
        }

        public int Excluir(int id)
        {
            Lancamento l = new Lancamento();
            return l.Excluir(id);
        }
    }
}
