﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Financeiro.Model;
using Financeiro.ViewModel;

namespace Financeiro.Controller
{
    public class UsuarioController
    {
        public UsuarioViewModel Autenticar(string email, string senha)
        {
            Usuario u = new Usuario().Autenticar(email, senha);
            if (u != null)
            {
                return new UsuarioViewModel()
                {
                    Email = u.Email,
                    Bairro = u.Bairro,
                    Cep = u.Cep,
                    Cidade = u.Cidade,
                    Endereco = u.Endereco,
                    Estado = u.Estado,
                    Nome = u.Nome,
                    Numero = u.Numero,
                    Senha = u.Senha,
                    Contas = null
                };
            }
            else
                return null;
        }
    }
}
