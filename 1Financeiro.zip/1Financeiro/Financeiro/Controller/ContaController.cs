﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Financeiro.Model;
using Financeiro.ViewModel;

namespace Financeiro.Controller
{
    public class ContaController
    {
        public List<ContaViewModel> Obter(string email)
        {
            List<Conta> contas = new Conta().Obter(email);
            if (contas != null)
            {
                return (from Conta c in contas
                        select new ContaViewModel()
                        {
                            Id = c.Id,
                            Agencia = c.Agencia,
                            AgenciaNumero = c.Agencia + "/" + c.Numero,
                            Banco = null,
                            BancoId = c.BancoId,
                            Lancamentos = null,
                            Numero = c.Numero,
                            Tipo = c.Tipo,
                            Usuario = null,
                            UsuarioEmail = c.UsuarioEmail
                        }).ToList();
            }
            else
                return null;
        }

        public ContaViewModel Obter(int id)
        {
            Conta c = new Conta().Obter(id);
            if (c != null)
            {
                ContaViewModel contaVM = new ContaViewModel()
                {
                    Id = c.Id,
                    Agencia = c.Agencia,
                    Banco = null,
                    BancoId = c.BancoId,
                    Lancamentos = null,
                    Numero = c.Numero,
                    Tipo = c.Tipo,
                    Usuario = null,
                    UsuarioEmail = c.UsuarioEmail
                };
                return contaVM;
            }
            else
                return null;
        }
    }
}
