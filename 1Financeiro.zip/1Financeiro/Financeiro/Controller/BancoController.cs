﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Financeiro.Model;
using Financeiro.ViewModel;

namespace Financeiro.Controller
{
    public class BancoController
    {
        public List<BancoViewModel> Obter()
        {
            List<Banco> bancos = new Model.Banco().Obter();
            if (bancos != null)
            {
                return (from Banco b in bancos
                        select new BancoViewModel()
                        {
                            Id = b.Id,
                            Nome = b.Nome,
                            Numero = b.Numero,
                            Contas = null
                        }).ToList();
            }
            else
                return null;
        }

        public BancoViewModel Obter(int id)
        {
            Banco b = new Banco().Obter(id);
            if (b != null)
            {
                BancoViewModel bancoVM = new BancoViewModel()
                {
                    Id = b.Id,
                    Nome = b.Nome,
                    Numero = b.Numero,
                    Contas = null
                };
                return bancoVM;
            }
            else
                return null;
        }

    }
}
