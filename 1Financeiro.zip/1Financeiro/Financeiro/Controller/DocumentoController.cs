﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Financeiro.Model;
using Financeiro.ViewModel;

namespace Financeiro.Controller
{
    public class DocumentoController
    {
        public List<DocumentoViewModel> Obter(int lancamentoId)
        {
            List<Documento> documentos = new Documento().Obter(lancamentoId);
            if (documentos != null)
            {
                return (from Documento d in documentos
                        select new DocumentoViewModel()
                        {
                            Id = d.Id,
                            Arquivo = d.Arquivo,
                            Lancamento = null,
                            LancamentoId = d.LancamentoId,
                            Legenda = d.Legenda
                        }).ToList();
            }
            else
                return null;
        }

        public DocumentoViewModel ObterDocumento(int id)
        {
            Documento d = new Documento().ObterDocumento(id);
            if (d != null)
            {
                DocumentoViewModel documentoVM = new DocumentoViewModel()
                {
                    Id = d.Id,
                    Arquivo = d.Arquivo,
                    Lancamento = null,
                    LancamentoId = d.LancamentoId,
                    Legenda = d.Legenda

                };
                return documentoVM;
            }
            else
                return null;
        }
    }
}
