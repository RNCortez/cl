﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Financeiro.ViewModel
{
    public class BancoViewModel
    {
        public int Id { get; set; }

        public string Numero { get; set; }

        public string Nome { get; set; }

        public List<ContaViewModel> Contas { get; set; }

    }
}
