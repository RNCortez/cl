﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Financeiro.ViewModel
{
    public class DocumentoViewModel
    {
        public int Id { get; set; }

        public int LancamentoId { get; set; }

        public string Legenda { get; set; }

        public string Arquivo { get; set; }

        public LancamentoViewModel Lancamento { get; set; }
    }
}
