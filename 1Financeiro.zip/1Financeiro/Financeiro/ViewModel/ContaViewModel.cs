﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Financeiro.ViewModel
{
    public class ContaViewModel
    {
        public int Id { get; set; }

        public string UsuarioEmail { get; set; }

        public int BancoId { get; set; }

        public string Agencia { get; set; }

        public string Numero { get; set; }

        public string AgenciaNumero { get; set; }

        public string Tipo { get; set; }

        public BancoViewModel Banco { get; set; }

        public List<LancamentoViewModel> Lancamentos { get; set; }

        public UsuarioViewModel Usuario { get; set; }
    }
}
