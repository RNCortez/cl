﻿using Financeiro.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Financeiro.Model
{
    internal class Lancamento
    {
        private int _id;
        private int _contaId;
        private DateTime _data;
        private string _tipo;
        private string _descricao;
        private decimal _valor;
        private List<Documento> _documentos;
        private Conta _conta;

        internal int Id
        {
            get
            {
                return _id;
            }

            set
            {
                _id = value;
            }
        }

        internal int ContaId
        {
            get
            {
                return _contaId;
            }

            set
            {
                _contaId = value;
            }
        }

        internal DateTime Data
        {
            get
            {
                return _data;
            }

            set
            {
                _data = value;
            }
        }

        internal string Tipo
        {
            get
            {
                return _tipo;
            }

            set
            {
                _tipo = value;
            }
        }

        internal string Descricao
        {
            get
            {
                return _descricao;
            }

            set
            {
                _descricao = value;
            }
        }

        internal decimal Valor
        {
            get
            {
                return _valor;
            }

            set
            {
                _valor = value;
            }
        }

        internal List<Documento> Documentos
        {
            get
            {
                return _documentos;
            }

            set
            {
                _documentos = value;
            }
        }

        internal Conta Conta
        {
            get
            {
                return _conta;
            }

            set
            {
                _conta = value;
            }
        }

        internal List<Lancamento> Obter(int contaId)
        {
            if (contaId > 0)
                return new LancamentoDAO().Obter(contaId);
            else
                return null;
        }

        internal Lancamento ObterLancamento(int id)
        {
            if (id > 0)
                return new LancamentoDAO().ObterLancamento(id);
            else
                return null;
        }

        internal List<Lancamento> ObterPeriodo(DateTime dataInicial, DateTime dataFinal, int contaId)
        {
            return new LancamentoDAO().ObterPeriodo(dataInicial, dataFinal, contaId);
        }

        internal decimal Saldo(DateTime dataInicial, DateTime dataFinal, int contaId)
        {
            return new LancamentoDAO().Saldo(dataInicial, dataFinal, contaId);
        }

        internal int Gravar()
        {
            if (this.Id >= 0 && (this.Tipo.ToUpper() == "D" || this.Tipo.ToUpper() == "C") &&
                this.ContaId > 0)
                return new LancamentoDAO().Gravar(this);
            else
                return -10;
        }

        internal int Excluir(int id)
        {
            if (id > 0)
                return new LancamentoDAO().Excluir(id);
            else
                return -10;
        }
    }
}
