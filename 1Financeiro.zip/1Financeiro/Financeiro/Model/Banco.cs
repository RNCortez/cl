﻿using Financeiro.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Financeiro.Model
{
    internal class Banco
    {
        private int _id;
        private string _numero;
        private string _nome;
        private List<Conta> _contas;

        internal int Id
        {
            get
            {
                return _id;
            }

            set
            {
                _id = value;
            }
        }

        internal string Numero
        {
            get
            {
                return _numero;
            }

            set
            {
                _numero = value;
            }
        }

        internal string Nome
        {
            get
            {
                return _nome;
            }

            set
            {
                _nome = value;
            }
        }

        internal List<Conta> Contas
        {
            get
            {
                return _contas;
            }

            set
            {
                _contas = value;
            }
        }

        internal List<Banco> Obter()
        {
            return new BancoDAO().Obter();
        }

        internal Banco Obter(int id)
        {
            if (id > 0)
                return new BancoDAO().Obter(id);
            else
                return null;
        }
    }
}
