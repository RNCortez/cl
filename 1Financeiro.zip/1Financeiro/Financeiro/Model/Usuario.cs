﻿using Financeiro.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Financeiro.Model
{
    internal class Usuario
    {
        private string _email;
        private string _nome;
        private string _cep;
        private string _endereco;
        private string _numero;
        private string _bairro;
        private string _cidade;
        private string _estado;
        private string _senha;
        private List<Conta> _contas;

        internal string Email
        {
            get
            {
                return _email;
            }

            set
            {
                _email = value;
            }
        }

        internal string Nome
        {
            get
            {
                return _nome;
            }

            set
            {
                _nome = value;
            }
        }

        internal string Cep
        {
            get
            {
                return _cep;
            }

            set
            {
                _cep = value;
            }
        }

        internal string Endereco
        {
            get
            {
                return _endereco;
            }

            set
            {
                _endereco = value;
            }
        }

        internal string Numero
        {
            get
            {
                return _numero;
            }

            set
            {
                _numero = value;
            }
        }

        internal string Bairro
        {
            get
            {
                return _bairro;
            }

            set
            {
                _bairro = value;
            }
        }

        internal string Cidade
        {
            get
            {
                return _cidade;
            }

            set
            {
                _cidade = value;
            }
        }

        internal string Estado
        {
            get
            {
                return _estado;
            }

            set
            {
                _estado = value;
            }
        }

        internal string Senha
        {
            get
            {
                return _senha;
            }

            set
            {
                _senha = value;
            }
        }

        internal List<Conta> Contas
        {
            get
            {
                return _contas;
            }

            set
            {
                _contas = value;
            }
        }

        internal Usuario Autenticar(string email, string senha)
        {
            if (email.Length > 0 && email.Contains("@") && senha.Length > 0)
                return new UsuarioDAO().Autenticar(email, senha);
            else
                return null;
        }
    }
}
