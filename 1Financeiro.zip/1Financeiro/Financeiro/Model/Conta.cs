﻿using Financeiro.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Financeiro.Model
{
    internal class Conta
    {
        private int _id;
        private string _usuarioEmail;
        private int _bancoId;
        private string _agencia;
        private string _numero;
        private string _tipo;
        private Banco _banco;
        private List<Lancamento> _lancamentos;
        private Usuario _usuario;

        internal int Id
        {
            get
            {
                return _id;
            }

            set
            {
                _id = value;
            }
        }

        internal string UsuarioEmail
        {
            get
            {
                return _usuarioEmail;
            }

            set
            {
                _usuarioEmail = value;
            }
        }

        internal int BancoId
        {
            get
            {
                return _bancoId;
            }

            set
            {
                _bancoId = value;
            }
        }

        internal string Agencia
        {
            get
            {
                return _agencia;
            }

            set
            {
                _agencia = value;
            }
        }

        internal string Numero
        {
            get
            {
                return _numero;
            }

            set
            {
                _numero = value;
            }
        }

        internal string Tipo
        {
            get
            {
                return _tipo;
            }

            set
            {
                _tipo = value;
            }
        }

        internal Banco Banco
        {
            get
            {
                return _banco;
            }

            set
            {
                _banco = value;
            }
        }

        internal List<Lancamento> Lancamentos
        {
            get
            {
                return _lancamentos;
            }

            set
            {
                _lancamentos = value;
            }
        }

        internal Usuario Usuario
        {
            get
            {
                return _usuario;
            }

            set
            {
                _usuario = value;
            }
        }

        internal List<Conta> Obter(string email)
        {
            if (email.Length > 0 && email.Contains("@"))
                return new ContaDAO().Obter(email);
            else
                return null;
        }

        internal Conta Obter(int id)
        {
            if (id > 0)
                return new ContaDAO().Obter(id);
            else
                return null;
        }
    }
}
