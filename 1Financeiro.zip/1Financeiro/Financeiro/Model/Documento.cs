﻿using Financeiro.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Financeiro.Model
{
    internal class Documento
    {
        private int _id;
        private int _lancamentoId;
        private string _legenda;
        private string _arquivo;
        private Lancamento _lancamento;

        internal int Id
        {
            get
            {
                return _id;
            }

            set
            {
                _id = value;
            }
        }

        internal int LancamentoId
        {
            get
            {
                return _lancamentoId;
            }

            set
            {
                _lancamentoId = value;
            }
        }

        internal string Legenda
        {
            get
            {
                return _legenda;
            }

            set
            {
                _legenda = value;
            }
        }

        internal string Arquivo
        {
            get
            {
                return _arquivo;
            }

            set
            {
                _arquivo = value;
            }
        }

        internal Lancamento Lancamento
        {
            get
            {
                return _lancamento;
            }

            set
            {
                _lancamento = value;
            }
        }

        internal List<Documento> Obter(int lancamentoId)
        {
            if (lancamentoId > 0)
                return new DocumentoDAO().Obter(lancamentoId);
            else
                return null;
        }

        internal Documento ObterDocumento(int id)
        {
            if (id > 0)
                return new DocumentoDAO().ObterDocumento(id);
            else
                return null;
        }
    }
}
