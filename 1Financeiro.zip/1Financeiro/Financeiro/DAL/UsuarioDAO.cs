﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Financeiro.Model;

namespace Financeiro.DAL
{
    internal class UsuarioDAO : BD
    {
        private List<Usuario> TableToList(DataTable dt)
        {
            List<Usuario> dados = null;
            if (dt != null && dt.Rows.Count > 0)
                dados = (from DataRow row in dt.Rows
                         select new Usuario()
                         {
                             Email = row["Email"].ToString(),
                             Nome = row["Nome"].ToString(),
                             Senha = row["Senha"].ToString(),
                             Cep = row["Cep"].ToString(),
                             Endereco = row["Endereco"].ToString(),
                             Numero = row["Numero"].ToString(),
                             Bairro = row["Bairro"].ToString(),
                             Cidade = row["Cidade"].ToString(),
                             Estado = row["Estado"].ToString(),
                             Contas = null
                         }).ToList();
            return dados;
        }

        internal Usuario Autenticar(string email, string senha)
        {
            ComandoSQL.Parameters.Clear();
            ComandoSQL.CommandText = @"select * from Usuario
                                       where Email = @email and Senha = @senha";
            ComandoSQL.Parameters.AddWithValue("@email", email);
            ComandoSQL.Parameters.AddWithValue("@senha", senha);
            DataTable dt = ExecutaSelect();
            var dados = TableToList(dt);

            return dados == null ? null : dados.FirstOrDefault();
        }
    }
}
