﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Financeiro.Model;

namespace Financeiro.DAL
{
    internal class BancoDAO : BD
    {
        private List<Banco> TableToList(DataTable dt)
        {
            List<Banco> dados = null;
            if (dt != null && dt.Rows.Count > 0)
                dados = (from DataRow row in dt.Rows
                         select new Banco()
                         {
                             Id = Convert.ToInt32(row["Id"].ToString()),
                             Numero = row["Numero"].ToString(),
                             Nome = row["Nome"].ToString(),
                             Contas = null
                         }).ToList();
            return dados;
        }

        internal List<Banco> Obter()
        {
            ComandoSQL.Parameters.Clear();
            ComandoSQL.CommandText = @"select * from Banco order by Nome";
            DataTable dados = ExecutaSelect();
            if (dados != null && dados.Rows.Count > 0)
                return TableToList(dados);
            else
                return null;
        }

        internal Banco Obter(int id)
        {
            ComandoSQL.Parameters.Clear();
            ComandoSQL.CommandText = @"select * from Banco where Id = @id";
            ComandoSQL.Parameters.AddWithValue("@id", id);
            DataTable dt = ExecutaSelect();
            var dados = TableToList(dt);

            return dados == null ? null : dados.FirstOrDefault();
        }
    }
}
