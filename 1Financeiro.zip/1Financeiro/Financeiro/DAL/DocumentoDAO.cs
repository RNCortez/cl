﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Financeiro.Model;

namespace Financeiro.DAL
{
    internal class DocumentoDAO : BD
    {
        private List<Documento> TableToList(DataTable dt)
        {
            List<Documento> dados = null;
            if (dt != null && dt.Rows.Count > 0)
                dados = (from DataRow row in dt.Rows
                         select new Documento()
                         {
                             Id = Convert.ToInt32(row["Id"].ToString()),
                             Arquivo = row["Arquivo"].ToString(),
                             Lancamento = null,
                             LancamentoId = Convert.ToInt32(row["LancamentoId"].ToString()),
                             Legenda = row["Legenda"].ToString()
                         }).ToList();
            return dados;
        }

        internal List<Documento> Obter(int lancamentoId)
        {
            ComandoSQL.Parameters.Clear();
            ComandoSQL.CommandText = @"select * from Documento where LancamentoId = @lancamentoId";
            ComandoSQL.Parameters.AddWithValue("@lancamentoId", lancamentoId);
            DataTable dados = ExecutaSelect();
            return TableToList(dados);
        }

        internal Documento ObterDocumento(int id)
        {
            ComandoSQL.Parameters.Clear();
            ComandoSQL.CommandText = @"select * from Documento where Id = @id";
            ComandoSQL.Parameters.AddWithValue("@id", id);
            DataTable dt = ExecutaSelect();
            var dados = TableToList(dt);

            return dados == null ? null : dados.FirstOrDefault();
        }
    }
}
