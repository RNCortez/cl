﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Financeiro.Model;

namespace Financeiro.DAL
{
    internal class LancamentoDAO : BD
    {
        private List<Lancamento> TableToList(DataTable dt)
        {
            List<Lancamento> dados = null;
            if (dt != null && dt.Rows.Count > 0)
                dados = (from DataRow row in dt.Rows
                         select new Lancamento()
                         {
                             Id = Convert.ToInt32(row["Id"].ToString()),
                             Conta = new ContaDAO().Obter(Convert.ToInt32(row["ContaId"].ToString())),
                             ContaId = Convert.ToInt32(row["ContaId"].ToString()),
                             Data = Convert.ToDateTime(row["Data"].ToString()),
                             Descricao = row["Descricao"].ToString(),
                             Documentos = null,
                             Tipo = row["Tipo"].ToString(),
                             Valor = Convert.ToDecimal(row["Valor"].ToString())
                         }).ToList();
            return dados;
        }

        internal List<Lancamento> Obter(int contaId)
        {
            ComandoSQL.Parameters.Clear();
            ComandoSQL.CommandText = @"select * from Lancamento where ContaId = @contaId";
            ComandoSQL.Parameters.AddWithValue("@contaId", contaId);
            DataTable dados = ExecutaSelect();
            if (dados != null && dados.Rows.Count > 0)
                return TableToList(dados);
            else
                return null;
        }

        internal Lancamento ObterLancamento(int id)
        {
            ComandoSQL.Parameters.Clear();
            ComandoSQL.CommandText = @"select * from Lancamento where id = @id";
            ComandoSQL.Parameters.AddWithValue("@id", id);
            DataTable dt = ExecutaSelect();
            var dados = TableToList(dt);

            return dados == null ? null : dados.FirstOrDefault();
        }

        internal List<Lancamento> ObterPeriodo(DateTime dataInicial, DateTime dataFinal, int contaId)
        {
            ComandoSQL.Parameters.Clear();
            ComandoSQL.CommandText = @"select * from Lancamento where ContaId = @contaId and Data between convert(datetime,@dataInicial,101) and convert(datetime,@dataFinal,101) order by Data";
            string dataI = string.Format("{0}-{1}-{2}", dataInicial.Year, dataInicial.Month, dataInicial.Day);
            string dataF = string.Format("{0}-{1}-{2} 23:59:59", dataFinal.Year, dataFinal.Month, dataFinal.Day);
            ComandoSQL.Parameters.AddWithValue("@dataInicial", dataI);
            ComandoSQL.Parameters.AddWithValue("@dataFinal", dataF);
            ComandoSQL.Parameters.AddWithValue("@contaId", contaId);
            DataTable dados = ExecutaSelect();
            if (dados != null && dados.Rows.Count > 0)
                return TableToList(dados);
            else
                return null;
        }

        internal decimal Saldo(DateTime dataInicial, DateTime dataFinal, int contaId)
        {
            ComandoSQL.Parameters.Clear();
            ComandoSQL.CommandText = @"select sum(Valor) from Lancamento where ContaId = @contaId and Data between convert(datetime,@dataInicial,101) and convert(datetime,@dataFinal,101)";
            string dataI = string.Format("{0}-{1}-{2}", dataInicial.Year, dataInicial.Month, dataInicial.Day);
            string dataF = string.Format("{0}-{1}-{2} 23:59:59", dataFinal.Year, dataFinal.Month, dataFinal.Day);
            ComandoSQL.Parameters.AddWithValue("@dataInicial", dataI);
            ComandoSQL.Parameters.AddWithValue("@dataFinal", dataF);
            ComandoSQL.Parameters.AddWithValue("@contaId", contaId);
            decimal saldo = (decimal)ExecutaScalar();
            return saldo;
        }

        internal int Gravar(Lancamento lancamento)
        {
            ComandoSQL.Parameters.Clear();
            if (lancamento.Id == 0)
                ComandoSQL.CommandText = @"insert into Lancamento (ContaId, Data, Tipo, Descricao, Valor) 
                            values (@contaId, @data, @tipo, @descricao, @valor)";
            else
            {
                ComandoSQL.CommandText = @"update Lancamento set ContaId = @contaId, Data = @data, 
                            Tipo = @tipo, Descricao = @descricao, Valor = @valor
                            where Id = @id";
                ComandoSQL.Parameters.AddWithValue("@id", lancamento.Id);
            }
            ComandoSQL.Parameters.AddWithValue("@contaId", lancamento.ContaId);
            ComandoSQL.Parameters.AddWithValue("@data", lancamento.Data);
            ComandoSQL.Parameters.AddWithValue("@tipo", lancamento.Tipo);
            ComandoSQL.Parameters.AddWithValue("@descricao", lancamento.Descricao);
            ComandoSQL.Parameters.AddWithValue("@valor", lancamento.Valor);

            return ExecutaComando();
        }

        internal int Excluir(int id)
        {
            int retorno = 1;
            ComandoSQL.Parameters.Clear();
            ComandoSQL.CommandText = @"delete from Documento where LancamentoId = @id";
            ComandoSQL.Parameters.AddWithValue("@id", id);
            if (ExecutaComando(true) >= 0)
            {
                ComandoSQL.CommandText = @"delete from Lancamento where Id = @id";
                if (ExecutaComando(true) > 0)
                    FinalizaTransacao(true);
                else
                {
                    FinalizaTransacao(false);
                    retorno = -20;
                }
            }
            else
            {
                FinalizaTransacao(false);
                retorno = -20;
            }
            return retorno;
        }


    }
}
