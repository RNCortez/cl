﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Financeiro.Model;

namespace Financeiro.DAL
{
    internal class ContaDAO : BD
    {
        private List<Conta> TableToList(DataTable dt)
        {
            List<Conta> dados = null;
            if (dt != null && dt.Rows.Count > 0)
                dados = (from DataRow row in dt.Rows
                         select new Conta()
                         {
                             Id = Convert.ToInt32(row["Id"].ToString()),
                             UsuarioEmail = row["UsuarioEmail"].ToString(),
                             BancoId = Convert.ToInt32(row["BancoId"].ToString()),
                             Agencia = row["Agencia"].ToString(),
                             Numero = row["Numero"].ToString(),
                             Tipo = row["Tipo"].ToString(),
                             Banco = null,
                             Lancamentos = null,
                             Usuario = null
                         }).ToList();
            return dados;
        }

        internal List<Conta> Obter(string email)
        {
            ComandoSQL.Parameters.Clear();
            ComandoSQL.CommandText = @"select * from Conta where UsuarioEmail = @email";
            ComandoSQL.Parameters.AddWithValue("@email", email);
            DataTable dados = ExecutaSelect();
            if (dados != null && dados.Rows.Count > 0)
                return TableToList(dados);
            else
                return null;
        }

        internal Conta Obter(int id)
        {
            ComandoSQL.Parameters.Clear();
            ComandoSQL.CommandText = @"select * from Conta where Id = @id";
            ComandoSQL.Parameters.AddWithValue("@id", id);
            DataTable dt = ExecutaSelect();
            var dados = TableToList(dt);

            return dados == null ? null : dados.FirstOrDefault();
        }

    }
}
