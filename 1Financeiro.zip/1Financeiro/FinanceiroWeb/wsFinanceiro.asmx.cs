﻿using Financeiro.Controller;
using Financeiro.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using cl = Financeiro.Controller;

namespace FinanceiroWeb
{
    /// <summary>
    /// Summary description for wsFinanceiro
    /// </summary>
    [WebService(Namespace = "http://fipp.unoeste.br/", Description = "WebService para a avaliação de PI-IV")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class wsFinanceiro : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }

        [WebMethod(Description = "Obter lançamentos de um usuário por período")]
        public List<LancamentoViewModel> ObterPorPeriodo(DateTime dataInicial, DateTime dataFinal, int contaId, string email, string senha)
        {
            if (new cl.UsuarioController().Autenticar(email, senha) != null)
                return new cl.LancamentoController().ObterPeriodo(dataInicial, dataFinal, contaId);
            else
                return null;
        }

        [WebMethod(Description = "Insere um novo lançamento para um determinado cliente")]
        public int NovoLancamento(int contaId, DateTime data, string tipo, string descricao, decimal valor, string email, string senha)
        {
            if (new cl.UsuarioController().Autenticar(email, senha) != null)
            {
                LancamentoViewModel l = new LancamentoViewModel();
                l.Id = 0;
                l.Conta = null;
                l.ContaId = contaId;
                l.Data = data;
                l.Tipo = tipo;
                l.Descricao = descricao;
                l.Valor = valor;

                cl.LancamentoController ctlLancamento = new LancamentoController();
                return ctlLancamento.Gravar(l);
            }
            else
                return -20;
        }
    }
}
