﻿function FormatarData(data) {
    var jsData = eval(data.replace(/\/Date\((\d+)\)\//gi, "new Date($1)"));
    var dataFormatada = jsData.toLocaleDateString();

    return dataFormatada;
};

function FormatarDataIso(data) {
    data = FormatarData(data);
    var d = data.split("/");
    return d[2] + "-" + d[1] + "-" + d[0];
}

function PreencherTabela(dados) {
    var txt = '<thead>\
            <tr>\
                <th>#ID</th>\
                <th>Conta</th>\
                <th>Data</th>\
                <th>Tipo</th>\
                <th>Descrição</th>\
                <th>Valor</th>\
                <th>...</th>\
            </tr>\
        </thead >\
        <tbody>';
    $.each(dados, function () {
        txt += '<tr><td>' + this.Id + '</td><td>' + this.ContaNumero + '</td><td>' + FormatarData(this.Data) +
            '</td><td>' + this.Tipo + '</td><td>' + this.Descricao + '</td><td>' + this.Valor + '</td><td>\
                <a role="button" class="btn btn-warning" href="javascript:Alterar(' + this.Id + ')">Alterar</a>\
                <a role="button" class="btn btn-danger" href="javascript:Excluir(' + this.Id + ')">Excluir</a>\
                </td></tr>';
    });
    txt += '</tbody>';
    $("#tableLancamentos").html(txt);
};

function ObterLancamentos() {
    $.ajax({
        type: 'POST',
        url: '/Lancamento/ObterPorPeriodo',
        data: { ddlMes: $("#ddlMes").val(), ddlAno: $("#ddlAno").val(), ddlContas: $("#ddlContas").val() },
        success: function (result) {
            if (result.length > 0) {
                PreencherTabela(result);
            }
            else {
                alert("Nenhum lançamento encontrado.");
            }
        },
        error: function (XMLHttpRequest, txtStatus, errorThrown) {
            alert("Status: " + txtStatus); alert("Error: " + errorThrown);
        }
    });
};

function Excluir(id) {
    if (confirm("Confirma a exclusão do registro #" + id + "?")) {
        $.ajax({
            type: 'POST',
            url: '/Lancamento/Excluir',
            data: { Id: id },
            success: function (result) {
                if (result == "") {
                    ObterLancamentos();
                }
                else {
                    alert(result);
                }
            },
            error: function (XMLHttpRequest, txtStatus, errorThrown) {
                alert("Status: " + txtStatus); alert("Error: " + errorThrown);
            }
        });
    }
};

function Alterar(id) {
    $.ajax({
        type: 'POST',
        url: '/Lancamento/Obter',
        data: { Id: id },
        success: function (result) {
            if (Object.keys(result).length > 0) {
                $.fancybox.open({
                    src: '#formLancamento',
                    type: 'inline'
                });
                $("#txtIdLancamento").val(result.Id);
                $("#selTipo").val(result.Tipo);
                $("#txtDescricao").val(result.Descricao);
                $("#txtData").val(FormatarDataIso(result.Data));
                $("#txtValor").val(result.Valor);
            }
        },
        error: function (XMLHttpRequest, txtStatus, errorThrown) {
            alert("Status: " + txtStatus); alert("Error: " + errorThrown);
        }
    });
};


$(document).ready(function () {
    $("#btnFiltrar").click(function () {
        ObterLancamentos();
    });

    $("#btnGravar").click(function () {
        var _id = $("#txtIdLancamento").val();
        var _contaId = $("#ddlContaLancamento").val();
        var _tipoConta = $("#selTipo").val();
        var _descricao = $("#txtDescricao").val();
        var _data = $("#txtData").val();
        var _valor = $("#txtValor").val();

        $("#txtIdLancamento").val(0);

        $.ajax({
            type: 'POST',
            url: '/Lancamento/Gravar',
            data: { txtIdLancamento: _id, ddlContaLancamento: _contaId, txtData: _data, selTipo: _tipoConta, txtDescricao: _descricao, txtValor: _valor },
            success: function (result) {
                if (result.length > 0) {
                    alert(result);
                }
                else {
                    $.fancybox.close();
                    ObterLancamentos();
                }
            },
            error: function (XMLHttpRequest, txtStatus, errorThrown) {
                alert("Status: " + txtStatus); alert("Error: " + errorThrown);
            }
        });
    });

    ObterLancamentos();
});