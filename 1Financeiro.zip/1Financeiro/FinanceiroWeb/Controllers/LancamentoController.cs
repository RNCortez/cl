﻿using vm = Financeiro.ViewModel;
using cl = Financeiro.Controller;
using FinanceiroWeb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FinanceiroWeb.Filters;
using Financeiro.ViewModel;

namespace FinanceiroWeb.Controllers
{
    [ValidarAcesso]
    public class LancamentoController : Controller
    {
        private void CarregarViewBags(int mesSelecao = 0, int anoSelecao = 0, int contaSelecao = 0)
        {
            HttpCookie ck = Request.Cookies["token"];

            List<Mes> meses = new Mes().Obter();
            List<int> anos = new List<int> { 2017, 2018, 2019, 2020 }; //Valores fixos só para teste... 
            List<vm.ContaViewModel> contas = new cl.ContaController().Obter(ck.Values["emailUsuario"].ToString());

            ViewBag.Mes = new SelectList(meses, "Numero", "Nome", mesSelecao);
            ViewBag.Ano = new SelectList(anos, anoSelecao);
            ViewBag.Contas = new SelectList(contas, "Id", "AgenciaNumero", contaSelecao);
        }

        public ActionResult Index()
        {
            CarregarViewBags(DateTime.Now.Month,DateTime.Now.Year);
            return View();
        }

        [HttpPost]
        public ActionResult ObterPorPeriodo(FormCollection form)
        {
            int mes = int.Parse(form["ddlMes"]);
            int ano = int.Parse(form["ddlAno"]);
            int contaId = int.Parse(form["ddlContas"]);

            DateTime dataInicial = new DateTime(ano, mes, 01);
            DateTime dataFinal = new DateTime(ano, mes, DateTime.DaysInMonth(ano, mes), 23, 59, 59);

            List<vm.LancamentoViewModel> lancamentos = new cl.LancamentoController().ObterPeriodo(dataInicial, dataFinal, contaId);

            return lancamentos == null ? Json("") : Json(lancamentos);
        }

        [HttpPost]
        public ActionResult Obter(int id)
        {
            cl.LancamentoController ctlLancamento = new cl.LancamentoController();
            var dados = ctlLancamento.ObterLancamento(id);
            return dados == null ? Json("") : Json(dados);
        }

        [HttpPost]
        public ActionResult Excluir(int id)
        {
            cl.LancamentoController ctlLancamento = new cl.LancamentoController();
            if (ctlLancamento.Excluir(id) > 0)
                return Json("");
            else
                return Json("Nenhum registro foi excluído.");
        }

        public ActionResult Gravar(FormCollection form)
        {
            int id = 0;
            int contaId = 0;
            DateTime data = DateTime.MinValue;
            string tipo = "C";
            string descricao = "";
            decimal valor = 0;

            int.TryParse(form["txtIdLancamento"], out id);
            int.TryParse(form["ddlContaLancamento"], out contaId);
            DateTime.TryParse(form["txtData"], out data);
            tipo = form["selTipo"];
            descricao = form["txtDescricao"];
            decimal.TryParse(form["txtValor"], out valor);

            LancamentoViewModel l = new LancamentoViewModel();
            l.Id = id;
            l.ContaId = contaId;
            l.Data = data;
            l.Tipo = tipo;
            l.Descricao = descricao;
            l.Valor = valor;

            cl.LancamentoController ctlLancamento = new cl.LancamentoController();
            if (ctlLancamento.Gravar(l) > 0)
                return Json("");
            else
                return Json("Não foi possível registrar o lançamento.");
        }
    }
}