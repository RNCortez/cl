﻿using FinanceiroWeb.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FinanceiroWeb.Controllers
{
    public class UsuarioController : Controller
    {
        [ValidarAcesso]
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Sair()
        {
            HttpCookie ck = Request.Cookies["token"];
            if (ck != null)
            {
                ck.Expires = DateTime.Now.AddDays(-1);
                Response.Cookies.Add(ck);
            }
            return RedirectToAction("Index", "Home");
        }
    }
}