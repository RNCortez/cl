﻿using FinanceiroWeb.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using cl = Financeiro.Controller;
using vm = Financeiro.ViewModel;

namespace FinanceiroWeb.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {

            HttpCookie ck = Request.Cookies["identificacao"];
            if (ck != null)
            {
                FormCollection form = new FormCollection();
                form.Add("txtEmail", ck["email"].ToString());
                form.Add("txtSenha", ck["senha"].ToString());
                form.Add("ckLembrar", "1");
                ViewData["formData"] = form;
            }

            return View();
        }

        [HttpPost]
        public ActionResult Index(FormCollection form)
        {
            ViewData["formData"] = form;
            cl.UsuarioController cUsuario = new cl.UsuarioController();
            vm.UsuarioViewModel vmUsuario = cUsuario.Autenticar(form["txtEmail"], form["txtSenha"]);
            if (vmUsuario != null)
            {
                HttpCookie ckToken = new HttpCookie("token");
                ckToken.Values.Add("emailUsuario", vmUsuario.Email);
                ckToken.Values.Add("autenticado", "ok");
                if (vmUsuario.Nome.Length > 15)
                    vmUsuario.Nome = vmUsuario.Nome.Substring(0, 15);
                ckToken.Values.Add("nomeUsuario", vmUsuario.Nome);
                Response.Cookies.Add(ckToken);

                if (form["ckLembrar"] == "1")
                {
                    HttpCookie ck = new HttpCookie("identificacao");
                    ck.Values.Add("email", form["txtEmail"]);
                    ck.Values.Add("senha", form["txtSenha"]);
                    ck.Expires = DateTime.Now.AddDays(90);
                    Response.Cookies.Add(ck);
                }
                else
                {
                    HttpCookie ck = Request.Cookies["identificacao"];
                    if (ck != null)
                    {
                        ck.Expires = DateTime.Now.AddDays(-1);
                        Response.Cookies.Add(ck);
                    }
                }
                return RedirectToAction("Dashboard", "Home");
            }
            else
            {
                ViewBag.Msg = "Usuário ou senha inválidos.";
            }
            return View();
        }

        [ValidarAcesso]
        public ActionResult Dashboard()
        {
            return View();
        }
    }
}