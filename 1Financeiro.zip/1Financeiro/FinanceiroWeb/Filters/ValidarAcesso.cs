﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FinanceiroWeb.Filters
{
    public class ValidarAcesso : FilterAttribute, IActionFilter
    {
        public void OnActionExecuted(ActionExecutedContext filterContext)
        {
            
        }

        public void OnActionExecuting(ActionExecutingContext filterContext)
        {
            HttpCookie ck = filterContext.HttpContext.Request.Cookies["token"];
            if (ck == null || ck.Values["autenticado"].ToString() != "ok")
            {
                filterContext.Result = new RedirectResult("/Usuario/Sair");
            }
        }
    }
}