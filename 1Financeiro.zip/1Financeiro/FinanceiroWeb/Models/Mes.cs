﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FinanceiroWeb.Models
{
    public class Mes
    {
        public int Numero { get; set; }
        public string Nome { get; set; }

        public List<Mes> Obter()
        {
            List<Mes> meses = new List<Mes>();
            meses.Add(new Mes { Numero = 1, Nome = "Janeiro" });
            meses.Add(new Mes { Numero = 2, Nome = "Fevereiro" });
            meses.Add(new Mes { Numero = 3, Nome = "Março" });
            meses.Add(new Mes { Numero = 4, Nome = "Abril" });
            meses.Add(new Mes { Numero = 5, Nome = "Maio" });
            meses.Add(new Mes { Numero = 6, Nome = "Junho" });
            meses.Add(new Mes { Numero = 7, Nome = "Julho" });
            meses.Add(new Mes { Numero = 8, Nome = "Agosto" });
            meses.Add(new Mes { Numero = 9, Nome = "Setembro" });
            meses.Add(new Mes { Numero = 10, Nome = "Outubro" });
            meses.Add(new Mes { Numero = 11, Nome = "Novembro" });
            meses.Add(new Mes { Numero = 12, Nome = "Dezembro" });
            return meses;
        }
    }
}